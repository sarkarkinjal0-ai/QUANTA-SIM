"""
QUANTA-SIM: Quantum Circuit Framework
Simulating Photonic Interference & Linear Optical Transformations through Quantum Circuits
Role: 4/5 - Qiskit Integration (Digital Quantum Side)

Standalone Comprehensive Verification & Demonstration Script:
1. Mach-Zehnder Interferometer (MZI) at fixed phase & continuous sweep (0 -> 2*pi).
2. Direct quantitative cross-validation: Optical Theory vs. Qiskit Aer Sampled Results (TVD, Fidelity).
3. Exact Analytical Z-Y-Z Euler Decomposition of arbitrary 2x2 optical unitaries.
4. 2-Photon Hong-Ou-Mandel (HOM) quantum bunching demonstration and coincidence dip curve.
5. 4-Mode dense linear optical network circuit synthesis.
6. Generation and saving of high-resolution scientific comparison figures.
"""

import io
import os
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import unitary_group

# Force UTF-8 stdout encoding for Windows console compatibility
if isinstance(sys.stdout, io.TextIOWrapper):
    if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
        sys.stdout.reconfigure(encoding="utf-8")

# Ensure matplotlib runs in headless Agg mode for scripted plot export
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Ensure local packages can be imported
sys.path.insert(0, str(Path(__file__).resolve().parent))

from qiskitintegration import (
    BeamSplitterConvention,
    ModeEncoding,
    get_beam_splitter_matrix,
    get_phase_shifter_matrix,
    decompose_unitary_zyz,
    verify_zyz_decomposition,
    QiskitOpticalCircuit,
    DigitalQuantumEngine,
    QuantumBenchmarks,
    plot_circuit,
    plot_probability_comparison,
    plot_mzi_interference_sweep,
    plot_hom_dip,
    plot_gate_breakdown,
)


def print_header(title: str) -> None:
    """Print a visually separated header section."""
    width = 78
    print("\n" + "=" * width)
    print(f"  {title.upper()}")
    print("=" * width)


def print_subheader(title: str) -> None:
    """Print a subheader."""
    print(f"\n--- {title} ---")


def run_mzi_demonstration(output_dir: Path) -> None:
    """Demonstrate Mach-Zehnder Interferometer simulation, benchmarking, and sweep."""
    print_header("Experiment 1: Mach-Zehnder Interferometer (MZI) Verification")

    # 1. Single Phase Point Analysis (phi = pi/3 = 60 deg)
    phi_test = np.pi / 3.0
    print(f"[+] Setting up MZI at internal phase shift phi = pi/3 (60.0 degrees)")
    print(f"    Input: Single photon injected into Mode 0 (|1, 0> optical -> |0> qubit)")
    print(f"    Beam Splitters: Two 50:50 splitters (Real-symmetric / Hadamard convention)")

    # Build circuit
    mzi_qc = QiskitOpticalCircuit.build_mach_zehnder(
        phase_phi=phi_test,
        input_mode=0,
        convention=BeamSplitterConvention.REAL_SYMMETRIC,
        add_measurement=True
    )

    # Save circuit diagrams
    circuit_mpl_path = output_dir / "mzi_circuit.png"
    circuit_text_path = output_dir / "mzi_circuit.txt"
    plot_circuit(mzi_qc, output="mpl", filename=str(circuit_mpl_path))
    plot_circuit(mzi_qc, output="text", filename=str(circuit_text_path))
    print(f"[✓] Circuit diagram exported to: {circuit_mpl_path.name}")

    # Theoretical optical probabilities
    # P0 = cos^2(phi/2) = cos^2(pi/6) = (sqrt(3)/2)^2 = 0.75
    # P1 = sin^2(phi/2) = sin^2(pi/6) = (1/2)^2 = 0.25
    opt_theory = {
        0: float(np.cos(phi_test / 2.0) ** 2),
        1: float(np.sin(phi_test / 2.0) ** 2)
    }

    # Run Simulation
    engine = DigitalQuantumEngine(seed=42)
    res_sv = engine.run_statevector(mzi_qc)
    res_shots = engine.run_shots(mzi_qc, num_shots=8192, seed=42)

    print_subheader("Output Probabilities at Detector Ports (Mode 0 & Mode 1)")
    print(f"{'Mode':<10} | {'Optical Theory':<16} | {'Qiskit Statevector':<19} | {'Qiskit (8192 shots)':<20}")
    print("-" * 72)
    for m in (0, 1):
        p_th = opt_theory[m]
        p_sv = res_sv.mode_probabilities[m]
        p_sh = res_shots.mode_probabilities[m]
        print(f"Mode {m:<5} | {p_th:<16.5f} | {p_sv:<19.5f} | {p_sh:<20.5f}")

    # Benchmark report
    report = QuantumBenchmarks.generate_report(
        circuit=mzi_qc,
        optical_theory_probs=opt_theory,
        qiskit_mode_probs=res_shots.mode_probabilities,
        shots=8192
    )

    print_subheader("Quantitative Verification Metrics")
    print(f"  • Total Variation Distance (TVD) : {report.total_variation_distance:.6f}  (Ideal: 0.0)")
    print(f"  • Classical Fidelity (Bhattacharyya) : {report.classical_fidelity:.6f}  (Ideal: 1.0)")
    print(f"  • Hellinger Distance                 : {report.hellinger_distance:.6f}  (Ideal: 0.0)")
    print(f"  • Quantum Circuit Depth              : {report.circuit_depth}")
    print(f"  • Total Quantum Gate Count           : {report.total_gates} (Ops: {report.gate_breakdown})")

    # Save probability comparison bar plot
    prob_plot_path = output_dir / "mzi_probability_comparison.png"
    plot_probability_comparison(opt_theory, res_shots.mode_probabilities, shots=8192,
                                title=f"MZI Detection Probabilities at φ = 60° (8192 Shots)",
                                filename=str(prob_plot_path))
    print(f"[✓] Probability comparison chart saved: {prob_plot_path.name}")

    # Save gate breakdown donut
    gate_plot_path = output_dir / "circuit_gate_breakdown.png"
    plot_gate_breakdown(report, filename=str(gate_plot_path))
    print(f"[✓] Gate composition chart saved: {gate_plot_path.name}")

    # 2. Continuous MZI Phase Sweep (0 to 2*pi)
    print_subheader("Executing Continuous MZI Phase Sweep (0° -> 360°, 45 sample points)")
    mzi_sweep = QiskitOpticalCircuit.sweep_mach_zehnder(
        num_points=45,
        convention=BeamSplitterConvention.REAL_SYMMETRIC,
        shots=4096,
        seed=100
    )

    print(f"  • Mean TVD across full 360° sweep : {mzi_sweep.mean_tvd:.5f}")
    print(f"  • Theoretical Fringe Visibility   : {mzi_sweep.visibility_theory:.4f}")
    print(f"  • Qiskit Sampled Visibility       : {mzi_sweep.visibility_qiskit:.4f}")

    sweep_plot_path = output_dir / "mzi_interference_sweep.png"
    plot_mzi_interference_sweep(mzi_sweep, filename=str(sweep_plot_path))
    print(f"[✓] MZI interference fringe plot saved: {sweep_plot_path.name}")


def run_zyz_decomposition_demonstration() -> None:
    """Demonstrate exact analytical Euler Z-Y-Z matrix decomposition."""
    print_header("Experiment 2: Analytical Euler Z-Y-Z Unitary Decomposition")

    print("[+] Testing analytical decomposition on an arbitrary 2x2 optical unitary operator:")
    # Construct arbitrary unitary matrix: U = BS(theta=0.62) @ PS(phi=1.14)
    u_bs = get_beam_splitter_matrix(theta=0.62, convention=BeamSplitterConvention.IMAGINARY_SYMMETRIC)
    u_ps = get_phase_shifter_matrix(phi=1.14)
    u_arbitrary = u_bs @ u_ps

    print("    Target Matrix U:")
    for row in u_arbitrary:
        print("     ", " ".join(f"{c.real:+.4f}{c.imag:+.4f}j" for c in row))

    # Analytical ZYZ decomposition
    alpha, beta, gamma, delta = decompose_unitary_zyz(u_arbitrary)
    print("\n[+] Extracted Euler Angles (radians & degrees):")
    print(f"    Global phase α = {alpha:+.5f} rad ({np.degrees(alpha):+.2f}°)")
    print(f"    Rotation   β = {beta:+.5f} rad ({np.degrees(beta):+.2f}°)")
    print(f"    Rotation   γ = {gamma:+.5f} rad ({np.degrees(gamma):+.2f}°)")
    print(f"    Rotation   δ = {delta:+.5f} rad ({np.degrees(delta):+.2f}°)")

    # Verify reconstruction
    is_valid = verify_zyz_decomposition(u_arbitrary, alpha, beta, gamma, delta, tol=1e-10)
    print(f"\n[✓] Mathematical Verification ||U - exp(i*α) Rz(β) Ry(γ) Rz(δ)|| < 1e-10: {is_valid}")
    assert is_valid, "ZYZ decomposition verification failed!"


def run_hom_demonstration(output_dir: Path) -> None:
    """Demonstrate 2-Photon Hong-Ou-Mandel effect and bunching on a 2-qubit circuit."""
    print_header("Experiment 3: 2-Photon Hong-Ou-Mandel (HOM) Quantum Bunching")

    print("[+] Physical Principle:")
    print("    Two indistinguishable photons enter opposite ports of a 50:50 beam splitter (|1, 1>).")
    print("    Destructive quantum interference between probability amplitudes completely cancels")
    print("    the coincidence detection outcome (|1, 1>). The photons emerge bunched in pairs:")
    print("    |psi_out> = (1/sqrt(2)) * (|2, 0> - |0, 2>).")

    print("\n[+] 2-Qubit Digital Quantum Circuit Mapping:")
    print("    |00> <---> |2, 0> (Mode 0 bunched)")
    print("    |01> <---> |1, 1> (Coincidence state)")
    print("    |11> <---> |0, 2> (Mode 1 bunched)")

    # 1. Fixed 50:50 Beam Splitter (theta = pi/4)
    hom_qc, fock_map = QiskitOpticalCircuit.build_hong_ou_mandel_2qubit(theta=np.pi / 4.0, add_measurement=True)

    hom_circuit_path = output_dir / "hom_circuit.png"
    plot_circuit(hom_qc, output="mpl", filename=str(hom_circuit_path))
    print(f"\n[✓] HOM circuit schematic saved to: {hom_circuit_path.name}")

    engine = DigitalQuantumEngine(seed=42)
    res_sv = engine.run_statevector(hom_qc)
    res_shots = engine.run_shots(hom_qc, num_shots=8192, seed=42)

    print_subheader("Measured 2-Qubit / Fock State Distribution at θ = 45° (50:50 BS)")
    print(f"{'Bitstring':<10} | {'Fock State Interpretation':<28} | {'Exact Theory':<14} | {'Sampled Freq (8192)':<18}")
    print("-" * 76)
    theory_map = {"00": 0.50, "01": 0.00, "11": 0.50, "10": 0.00}
    for b in ("00", "01", "11", "10"):
        desc = fock_map.get(b, "Unused")
        p_th = theory_map[b]
        p_sh = res_shots.probabilities.get(b, 0.0)
        print(f"|{b}>{'':<6} | {desc:<28} | {p_th:<14.3f} | {p_sh:<18.4f}")

    p_coincidence = res_shots.probabilities.get("01", 0.0)
    print(f"\n[✓] Coincidence Probability P(|1, 1>) = {p_coincidence:.4f} (HOM Dip: Drops to ZERO!)")
    print(f"[✓] Quantum Bunching P(|2,0>) + P(|0,2>) = {res_shots.probabilities.get('00', 0.0) + res_shots.probabilities.get('11', 0.0):.4f} (100% Bunching!)")

    # 2. Continuous HOM Dip Sweep over mixing angle theta (0 to pi/2)
    print_subheader("Sweeping Beam Splitter Mixing Angle θ (0° -> 90°) to trace full HOM Dip")
    hom_sweep = QiskitOpticalCircuit.sweep_hong_ou_mandel(num_points=40, shots=4096, seed=42)

    hom_dip_plot_path = output_dir / "hom_dip_curve.png"
    plot_hom_dip(hom_sweep, filename=str(hom_dip_plot_path))
    print(f"[✓] HOM coincidence dip curve saved: {hom_dip_plot_path.name}")
    print(f"    Theoretical Minimum Coincidence : {hom_sweep.min_coincidence_theory:.5f}")
    print(f"    Qiskit Measured Minimum Coincidence: {hom_sweep.min_coincidence_qiskit:.5f}")
    print(f"    TVD Error at Dip Minimum        : {hom_sweep.tvd_at_dip:.5f}")


def run_4mode_demonstration(output_dir: Path) -> None:
    """Demonstrate dense log2(N) encoding on a 4-mode linear optical network."""
    print_header("Experiment 4: 4-Mode Optical Interferometer (Dense 2-Qubit Encoding)")

    print("[+] Mapping 4 optical spatial modes to 2 qubits: Mode k -> binary(k)")
    print("    Mode 0 -> |00>, Mode 1 -> |01>, Mode 2 -> |10>, Mode 3 -> |11>")

    # Construct unitary optical matrix for a 4-mode Hadamard-like multiport
    np.random.seed(42)
    u_4x4 = unitary_group.rvs(4)

    # Launch single photon into Mode 2 (|0, 0, 1, 0> optical -> |10> qubit)
    input_mode = 2
    qc_4mode = QiskitOpticalCircuit.build_4mode_network(u_4x4, input_mode=input_mode, add_measurement=True)

    engine = DigitalQuantumEngine(seed=42)
    res_sv = engine.run_statevector(qc_4mode, encoding=ModeEncoding.DENSE, total_modes=4)
    res_shots = engine.run_shots(qc_4mode, num_shots=8192, encoding=ModeEncoding.DENSE, total_modes=4, seed=42)

    # Optical theoretical probabilities: column `input_mode` of U
    opt_theory = {m: float(np.abs(u_4x4[m, input_mode]) ** 2) for m in range(4)}

    print_subheader("Output Probabilities across 4 Optical Modes")
    print(f"{'Mode':<10} | {'Optical Theory (P_opt)':<24} | {'Qiskit Sampled (P_qiskit)':<24}")
    print("-" * 62)
    for m in range(4):
        print(f"Mode {m:<5} | {opt_theory[m]:<24.5f} | {res_shots.mode_probabilities[m]:<24.5f}")

    tvd = QuantumBenchmarks.total_variation_distance(opt_theory, res_shots.mode_probabilities)
    fidelity = QuantumBenchmarks.classical_fidelity(opt_theory, res_shots.mode_probabilities)
    print(f"\n[✓] 4-Mode Network TVD       : {tvd:.6f}")
    print(f"[✓] 4-Mode Network Fidelity  : {fidelity:.6f}")


def main() -> None:
    """Main verification execution pipeline."""
    # Ensure artifacts directory exists
    output_dir = Path(__file__).resolve().parent / "artifacts"
    output_dir.mkdir(parents=True, exist_ok=True)

    print("\n" + "#" * 78)
    print("  QUANTA-SIM: DIGITAL QUANTUM SIMULATION WING (QISKIT 1.0+ STANDARDS)")
    print("  VIT Chennai Engineering Physics Project — Role 4/5 Integration Core")
    print("#" * 78)

    try:
        run_mzi_demonstration(output_dir)
        run_zyz_decomposition_demonstration()
        run_hom_demonstration(output_dir)
        run_4mode_demonstration(output_dir)

        print_header("All Verification Tests Completed Successfully!")
        print(f"[✓] All generated scientific plots have been saved to directory:")
        print(f"    {output_dir}")
        print("[✓] Ready for integration into Streamlit UI Dashboard (Role 5/5).")
        print("=" * 78 + "\n")

    except Exception as e:
        print(f"\n[!] Demonstration halted with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
