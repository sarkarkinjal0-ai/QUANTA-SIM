"""
QUANTA-SIM: Quantum Circuit Framework
Subpackage: quanta_sim.quantum_bridge (Role 4/5: Qiskit Integration - Digital Quantum Side)

This module forwards all functionality from the core qiskitintegration package.
"""

from qiskitintegration import *
from qiskitintegration import (
    BeamSplitterConvention,
    ModeEncoding,
    get_beam_splitter_matrix,
    get_phase_shifter_matrix,
    decompose_unitary_zyz,
    verify_zyz_decomposition,
    apply_zyz_to_circuit,
    embed_unitary_dense,
    embed_givens_dual_rail,
    optical_state_to_qubit_amplitudes,
    qubit_counts_to_mode_probabilities,
    QiskitOpticalCircuit,
    MZISweepResult,
    HOMSweepResult,
    DigitalQuantumEngine,
    SimulationResult,
    QuantumBenchmarks,
    BenchmarkReport,
    plot_circuit,
    plot_probability_comparison,
    plot_mzi_interference_sweep,
    plot_hom_dip,
    plot_gate_breakdown,
)

__all__ = [
    "BeamSplitterConvention",
    "ModeEncoding",
    "get_beam_splitter_matrix",
    "get_phase_shifter_matrix",
    "decompose_unitary_zyz",
    "verify_zyz_decomposition",
    "apply_zyz_to_circuit",
    "embed_unitary_dense",
    "embed_givens_dual_rail",
    "optical_state_to_qubit_amplitudes",
    "qubit_counts_to_mode_probabilities",
    "QiskitOpticalCircuit",
    "MZISweepResult",
    "HOMSweepResult",
    "DigitalQuantumEngine",
    "SimulationResult",
    "QuantumBenchmarks",
    "BenchmarkReport",
    "plot_circuit",
    "plot_probability_comparison",
    "plot_mzi_interference_sweep",
    "plot_hom_dip",
    "plot_gate_breakdown",
]
