# QUANTA-SIM — Final Integrated Project

## Team architecture

Optical Builder
→ Core Physics & Math
→ **Photon & Noise Engine (Advanced Simulation)**
→ Interferometry & Experiments
→ Qiskit Digital Quantum Side
→ Benchmarking / Visualization

## Your module: Photon & Noise Engine

`photon_noise_engine.py` is the central advanced simulation layer. It provides:
- single-photon evolution through arbitrary 2–4 mode builder circuits
- two-photon/Fock-state output probabilities
- HOM interference amplitudes
- phase drift and beam-splitter reflectivity noise
- finite-shot multinomial/binomial sampling
- MZI sweeps and noise analysis

## Optical Builder integration

The teammate's builder is under `optical_builder/`.
`OpticalCircuit` stores the same ordered BS/PS circuit definition and computes
the global unitary. Its simulation methods delegate to `PhotonNoiseEngine`,
so photon physics is not duplicated in the UI/builder.

Run the integrated Streamlit app:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Run the core integration tests:

```bash
python test_integration.py
```

Optional Qiskit benchmark:

```python
from photon_qiskit_bridge import benchmark_mzi_with_qiskit
result = benchmark_mzi_with_qiskit(phase=1.0, shots=8192)
print(result["tvd"], result["classical_fidelity"], result["hellinger_distance"])
```

## Division of responsibility

- Optical Builder: circuit construction and user-facing component selection.
- Core Physics: unitary mathematics and deterministic state evolution.
- Photon & Noise Engine: photon-specific advanced simulation and stochastic imperfections.
- Interferometry: MZI/HOM experiment orchestration and analysis.
- Qiskit: digital quantum-circuit construction, Aer sampling, and statistical comparison.
