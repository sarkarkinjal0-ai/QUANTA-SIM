import numpy as np
import streamlit as st
from optical_builder.utils.builder_tab import render_integrated_builder_tab
from physics_experiments import InterferometryExperiments
from photon_noise_engine import PhotonNoiseEngine

st.set_page_config(page_title="QUANTA-SIM", layout="wide")
st.title("QUANTA-SIM — Integrated Photonic Quantum Simulator")
st.caption("Optical Builder → Core Physics → Photon & Noise Engine → Experiments → Qiskit Benchmarking")

tab1,tab2,tab3=st.tabs(["Circuit Builder","MZI / Experiments","Photon & Noise Engine"])
with tab1:
    render_integrated_builder_tab()
with tab2:
    st.header("Interferometry & Experiments")
    ref=st.slider("Nominal beam-splitter reflectivity",0.0,1.0,0.5,0.01)
    noise=st.toggle("Enable phase / component noise",value=False)
    sigma=st.slider("Phase drift σ",0.0,1.0,0.10,0.01) if noise else 0.0
    rstd=st.slider("Reflectivity drift σ",0.0,0.2,0.02,0.005) if noise else 0.0
    eng=PhotonNoiseEngine(seed=42)
    phis=np.linspace(0,2*np.pi,100)
    sweep=eng.mzi_sweep(phis,reflectivity=ref,phase_drift_std=sigma,
                        reflectivity_std=rstd,noisy=noise,shots=1024)
    st.line_chart({"Ideal P0":sweep["p0_ideal"],"Noisy P0":sweep["p0_noisy"]})
    st.write("Noisy MZI visibility:",float((sweep["p0_noisy"].max()-sweep["p0_noisy"].min())/
                                           max(1e-12,sweep["p0_noisy"].max()+sweep["p0_noisy"].min())))
    hom=eng.simulate_hom(reflectivity=ref,noisy=noise,reflectivity_std=rstd,shots=4096)
    st.subheader("HOM")
    st.json(hom["probabilities"])
    st.write("Sampled counts:",hom["sampled_counts"])
with tab3:
    st.header("Photon & Noise Engine")
    st.markdown("""
**Your team's advanced simulation layer.** It performs single-photon evolution,
two-photon/Fock interference, controlled optical imperfections, and finite-shot
sampling. Downstream experiments consume its probabilities; Qiskit consumes the
same physical transformation for benchmarking.
""")
    st.code("""PhotonNoiseEngine.simulate_circuit(...)
PhotonNoiseEngine.simulate_two_photon_circuit(...)
PhotonNoiseEngine.mzi_sweep(...)
PhotonNoiseEngine.simulate_hom(...)""")
