import numpy as np

class ComponentLibrary:
    """
    [TEAM ROLE: Optical Components - Optical Builder]
    This module defines the raw 2x2 complex unitary matrices for physical hardware.
    """
    
    @staticmethod
    def beam_splitter(reflectivity=0.5):
        """Tunable Beam Splitter allowing for manufacturing imperfections."""
        r_amp = np.sqrt(reflectivity)
        t_amp = np.sqrt(1.0 - reflectivity)
        return np.array([[t_amp, 1j * r_amp], 
                         [1j * r_amp, t_amp]], dtype=complex)

    @staticmethod
    def beam_splitter_5050():
        """Standard symmetric 50:50 Beam Splitter."""
        return ComponentLibrary.beam_splitter(reflectivity=0.5)

    @staticmethod
    def phase_shifter(phi, phase_drift_std=0.0):
        """Phase Shifter with optional environmental drift/noise."""
        actual_phi = np.random.normal(loc=phi, scale=phase_drift_std)
        return np.array([[np.exp(1j * actual_phi), 0], 
                         [0, 1]], dtype=complex)