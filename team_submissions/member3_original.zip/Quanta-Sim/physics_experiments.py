import numpy as np
# ---------------------------------------------------------
# UPSTREAM DATA INTEGRATION
# We import matrices and logic from the Builder and Engine teams
# ---------------------------------------------------------
from optical_components import ComponentLibrary
from simulation_engine import SinglePhotonPipeline, MultiModeLogic, TwoPhotonInterference

class InterferometryExperiments:
    """
    [YOUR TEAM ROLE: Interferometry & Experiments]
    You design the circuits and run the sweeps. 
    Crucially, you DO NOT plot the data here. You return raw data structures
    to be consumed by the UI/Visualization downstream team.
    """
    
    @staticmethod
    def run_mzi_sweep(imperfect_reflectivity=0.45, noise_std=0.3):
        """Constructs and sweeps an MZI circuit, returning raw probability arrays."""
        initial_state = [1, 0] # |1,0>
        phi_values = np.linspace(0, 2 * np.pi, 100)
        
        prob_mode_0_ideal = []
        prob_mode_1_ideal = []
        prob_mode_0_noisy = []
        
        bs_ideal = ComponentLibrary.beam_splitter_5050()
        bs_imperfect = ComponentLibrary.beam_splitter(reflectivity=imperfect_reflectivity) 
        
        for phi in phi_values:
            # --- Ideal Circuit ---
            pipe_ideal = SinglePhotonPipeline(initial_state)
            pipe_ideal.add_component(bs_ideal)
            pipe_ideal.add_component(ComponentLibrary.phase_shifter(phi))
            pipe_ideal.add_component(bs_ideal)
            probs_ideal = pipe_ideal.extract_probabilities()
            prob_mode_0_ideal.append(probs_ideal[0])
            prob_mode_1_ideal.append(probs_ideal[1])
            
            # --- Noisy Circuit ---
            pipe_noisy = SinglePhotonPipeline(initial_state)
            pipe_noisy.add_component(bs_imperfect)
            pipe_noisy.add_component(ComponentLibrary.phase_shifter(phi, phase_drift_std=noise_std))
            pipe_noisy.add_component(bs_imperfect)
            probs_noisy = pipe_noisy.extract_probabilities()
            prob_mode_0_noisy.append(probs_noisy[0])

        # DOWNSTREAM DATA CONTRACT: Return a clean dictionary to the UI team
        return {
            "phi_values": phi_values,
            "p0_ideal": prob_mode_0_ideal,
            "p1_ideal": prob_mode_1_ideal,
            "p0_noisy": prob_mode_0_noisy
        }

    @staticmethod
    def run_hom_analysis(imperfect_reflectivity=0.45):
        """Analyzes HOM effect and returns exact coincidence probabilities."""
        bs_ideal = ComponentLibrary.beam_splitter_5050()
        bs_imperfect = ComponentLibrary.beam_splitter(reflectivity=imperfect_reflectivity) 
        
        MultiModeLogic.validate_unitarity(bs_ideal)
        MultiModeLogic.validate_unitarity(bs_imperfect)
        
        amp_ideal = TwoPhotonInterference.calculate_hom_amplitudes(bs_ideal)
        amp_imperfect = TwoPhotonInterference.calculate_hom_amplitudes(bs_imperfect)
        
        p11_ideal = np.abs(amp_ideal["|1,1>"])**2
        p11_imperfect = np.abs(amp_imperfect["|1,1>"])**2
        
        # DOWNSTREAM DATA CONTRACT
        return {
            "ideal_coincidence": p11_ideal,
            "imperfect_coincidence": p11_imperfect
        }