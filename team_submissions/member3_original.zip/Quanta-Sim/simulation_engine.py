import numpy as np

class SinglePhotonPipeline:
    """
    [TEAM ROLE: Core Physics & Math - Simulation Engine]
    Manages state evolution of a single photon through a linear optical circuit.
    """
    def __init__(self, initial_state):
        self.initial_state = np.array(initial_state, dtype=complex)
        self.components = []
        self.total_unitary = None
        self.final_state = None

    def add_component(self, unitary_matrix):
        self.components.append(np.array(unitary_matrix, dtype=complex))

    def cascade(self):
        if not self.components:
            raise ValueError("No components added to the circuit.")
        self.total_unitary = self.components[0]
        for i in range(1, len(self.components)):
            self.total_unitary = np.matmul(self.components[i], self.total_unitary)
        return self.total_unitary

    def compute_state(self):
        if self.total_unitary is None:
            self.cascade()
        self.final_state = np.matmul(self.total_unitary, self.initial_state)
        return self.final_state

    def extract_probabilities(self):
        if self.final_state is None:
            self.compute_state()
        return np.abs(self.final_state)**2

class MultiModeLogic:
    """Scales isolated 2-mode components into larger dimensional spaces."""
    @staticmethod
    def expand_with_tensor_product(local_unitary, system_index, total_systems=2):
        identity = np.eye(2, dtype=complex)
        global_unitary = local_unitary if system_index == 0 else identity
        for i in range(1, total_systems):
            if i == system_index:
                global_unitary = np.kron(global_unitary, local_unitary)
            else:
                global_unitary = np.kron(global_unitary, identity)
        return global_unitary

    @staticmethod
    def validate_unitarity(matrix, tolerance=1e-10):
        matrix = np.array(matrix)
        identity_approx = np.matmul(matrix.conj().T, matrix)
        is_unitary = np.allclose(identity_approx, np.eye(matrix.shape[0]), atol=tolerance)
        if not is_unitary:
            raise ValueError("Matrix is not unitary!")
        return is_unitary

class TwoPhotonInterference:
    """
    [TEAM ROLE: Photon & Noise Engine - Advanced Simulation]
    Multi-photon Fock state solvers.
    """
    @staticmethod
    def calculate_hom_amplitudes(unitary):
        a, b = unitary[0, 0], unitary[0, 1]
        c, d = unitary[1, 0], unitary[1, 1]
        
        amp_20 = np.sqrt(2) * (a * b)
        amp_11 = (a * d) + (b * c)
        amp_02 = np.sqrt(2) * (c * d)
        
        return {"|2,0>": amp_20, "|1,1>": amp_11, "|0,2>": amp_02}